# 1450px Layout Correction

- Corrected `.market-seo-section` on the homepage. It formerly used `margin:34px 0 44px` and no width, so it stretched to the viewport edges.
- It now uses `width:min(1450px, calc(100% - 64px))`, `max-width:1450px`, and horizontal auto margins.
- Mobile widths below 600px use 16px side gutters.
- Existing `.wrap` site containers already use a 1450px maximum width and centered alignment.
- Background bands remain full width where appropriate; content inside uses constrained containers.
- Bumped marketplace stylesheet query version to avoid stale cached CSS.

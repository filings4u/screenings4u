# Stripe webhook integration — mandatory before enabling cart checkout

The deployed `stripe-webhook` function currently runs `fulfillTestingOrder(orderId)` after payment. The `fulfillTestingOrder` helper loops over `order_items` and immediately creates `testing_cases`, `testing_labcorp_orders` and `testing_donor_passes`. This must **not** run for cart items whose `metadata.assignment_deferred` is `true`. Those items have no donor at purchase time.

In `fulfillTestingOrder`, replace the current `const items=(iq.data||[]).filter(...)` statement with a two-part filter:

```ts
const websiteItems=(iq.data||[]).filter((x:any)=>x.services?.metadata?.public_site==="screenings4u"&&x.services?.metadata?.public_catalog===true&&x.services?.metadata?.testing_operation===true);
const deferredItems=websiteItems.filter((x:any)=>x.metadata?.assignment_deferred===true);
const items=websiteItems.filter((x:any)=>x.metadata?.assignment_deferred!==true);
```

If deferredItems exist and items is empty, **do not** return before granting customer portal access. Upsert `testing_customer_portal_access`, enqueue a `notifications` entry to assign donors, send a customer receipt/email through the existing `testingMail` helper, and update `orders.metadata.donor_assignment_status` to `awaiting_donors`. Guard customer notifications with an idempotent metadata flag and handle replay/concurrency. Do not set `fulfillment_status` to `processing` until donors are assigned. Preserve the existing single-test behavior for items not deferred.

**Do not deploy the new cart endpoint without deploying and testing this webhook modification first.** The next project step builds customer-portal donor assignment and its protected server-side validation/fulfillment workflow.

import Stripe from "npm:stripe@18.5.0";
import { createClient } from "npm:@supabase/supabase-js@2";

// Deploy only after the existing Stripe webhook has been updated to skip
// order_items whose metadata.assignment_deferred === true.
const cors = {"Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"authorization,content-type,apikey,x-client-info", "Access-Control-Allow-Methods":"POST,OPTIONS"};
const reply = (body: unknown, status=200) => new Response(JSON.stringify(body), {status, headers:{...cors,"Content-Type":"application/json","Cache-Control":"no-store"}});
const clean=(x:unknown)=>String(x??"").trim();
const cents=(x:unknown)=>Math.round(Number(x)*100);
const validEmail=(email:string)=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

Deno.serve(async(req:Request)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return reply({error:"Method not allowed."},405);
 let createdOrderId:string|null=null,createdIntentId:string|null=null;
 try{
  const url=Deno.env.get("SUPABASE_URL")||"",serviceKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||"",stripeKey=Deno.env.get("STRIPE_SECRET_KEY")||"",publishable=Deno.env.get("STRIPE_PUBLISHABLE_KEY")||"";
  if(!url||!serviceKey||!stripeKey||!publishable)return reply({error:"Payment service unavailable."},503);
  const db=createClient(url,serviceKey,{auth:{persistSession:false,autoRefreshToken:false}});
  const stripe=new Stripe(stripeKey,{apiVersion:"2025-08-27.basil"});
  const body=await req.json().catch(()=>null);
  if(!body||!Array.isArray(body.items))return reply({error:"Cart items are required."},400);
  const entries=body.items;
  if(!entries.length||entries.length>50)return reply({error:"Cart must contain 1 to 50 different tests."},400);
  const unitTotal=entries.reduce((v:any,x:any)=>v+Number(x?.quantity),0);
  if(!Number.isSafeInteger(unitTotal)||unitTotal<2||unitTotal>100)return reply({error:"Cart must contain 2 to 100 tests."},400);
  const parsed=entries.map((x:any)=>({key:clean(x?.serviceId),quantity:Number(x?.quantity)}));
  if(parsed.some((x:any)=>!x.key||!Number.isSafeInteger(x.quantity)||x.quantity<1||x.quantity>50))return reply({error:"Invalid test quantity or service."},400);
  if(new Set(parsed.map((x:any)=>x.key)).size!==parsed.length)return reply({error:"Duplicate service entries are not allowed."},400);
  const customer=body.customer||{},email=clean(customer.email).toLowerCase(),firstName=clean(customer.firstName),lastName=clean(customer.lastName);
  if(!firstName||!lastName||!validEmail(email)||!clean(customer.address)||!clean(customer.city)||!clean(customer.state)||!/^\d{5}(?:-\d{4})?$/.test(clean(customer.zip)))return reply({error:"Valid customer and billing details are required."},400);
  const catalog=await db.from("services").select("id,slug,name,active,metadata").eq("active",true).in("slug",parsed.map((x:any)=>x.key));
  if(catalog.error)throw catalog.error;
  const rows=[] as {service:any;quantity:number;unitCents:number;currency:string}[];
  const now=new Date().toISOString();
  for(const entry of parsed){
   const service=(catalog.data||[]).find((s:any)=>s.slug===entry.key);
   if(!service||service.metadata?.public_catalog!==true||service.metadata?.public_site!=="screenings4u"||service.metadata?.testing_operation!==true)return reply({error:`Test ${entry.key} is not available for online checkout.`},409);
   const q=await db.from("service_prices").select("amount,currency").eq("service_id",service.id).eq("active",true).lte("effective_from",now).or(`effective_to.is.null,effective_to.gt.${now}`).order("effective_from",{ascending:false}).limit(1).maybeSingle();
   if(q.error)throw q.error;
   const unitCents=cents(q.data?.amount);
   if(!Number.isSafeInteger(unitCents)||unitCents<=0)return reply({error:`Current price is unavailable for ${service.name}.`},409);
   rows.push({service,quantity:entry.quantity,unitCents,currency:clean(q.data?.currency||"USD").toLowerCase()});
  }
  if(new Set(rows.map(x=>x.currency)).size!==1)return reply({error:"All cart tests must use the same currency."},409);
  const currency=rows[0].currency,subtotalCents=rows.reduce((v,x)=>v+x.unitCents*x.quantity,0);
  if(subtotalCents>99999999)return reply({error:"Please contact support for this order volume."},409);
  let discountAmountCents=0,discountId:string|null=null,discountCode:string|null=null;
  const requestedCode=clean(body.discountCode).toUpperCase();
  if(requestedCode){
   const dr=await db.from("discount_codes").select("*").ilike("code",requestedCode).maybeSingle();if(dr.error)throw dr.error;
   const d=dr.data;
   if(!d?.active)return reply({error:"That discount code is not valid."},409);
   if(d.starts_at&&new Date(d.starts_at).getTime()>Date.now())return reply({error:"Discount not active yet."},409);
   if(d.ends_at&&new Date(d.ends_at).getTime()<=Date.now())return reply({error:"Discount has expired."},409);
   const channels=Array.isArray(d.channels)?d.channels.map((x:unknown)=>clean(x).toLowerCase()):[];
   if(channels.length&&!channels.includes("website"))return reply({error:"This code cannot be used on this website."},409);
   if(cents(d.minimum_subtotal||0)>subtotalCents)return reply({error:"Order does not meet the discount minimum."},409);
   if(d.max_redemptions){const r=await db.from("discount_redemptions").select("id",{head:true,count:"exact"}).eq("discount_code_id",d.id);if(r.error)throw r.error;if((r.count||0)>=Number(d.max_redemptions))return reply({error:"Discount redemption limit reached."},409)}
   if(d.max_redemptions_per_customer){const r=await db.from("discount_redemptions").select("id",{head:true,count:"exact"}).eq("discount_code_id",d.id).ilike("customer_email",email);if(r.error)throw r.error;if((r.count||0)>=Number(d.max_redemptions_per_customer))return reply({error:"Customer redemption limit reached."},409)}
   let eligibleCents=subtotalCents;
   if(!d.applies_to_all_services){const map=await db.from("discount_code_services").select("service_id").eq("discount_code_id",d.id).in("service_id",rows.map(x=>x.service.id));if(map.error)throw map.error;
    const allowed=new Set((map.data||[]).map((x:any)=>x.service_id));eligibleCents=rows.filter(x=>allowed.has(x.service.id)).reduce((v,x)=>v+x.unitCents*x.quantity,0);
    if(!eligibleCents)return reply({error:"This discount does not apply to your cart."},409);
   }
   const raw=d.discount_type==="percent"?Math.round(eligibleCents*Number(d.discount_value)/100):cents(d.discount_value||0);
   discountAmountCents=Math.max(0,Math.min(eligibleCents,raw));
   if(d.maximum_discount_amount!=null)discountAmountCents=Math.min(discountAmountCents,cents(d.maximum_discount_amount));
   discountId=d.id;discountCode=clean(d.code).toUpperCase();
  }
  const amount=subtotalCents-discountAmountCents;
  if(amount<50)return reply({error:"Order total must be at least $0.50."},409);
  // Uses the same guest-profile creation strategy as the existing single-test endpoint.
  // Find existing customers by indexed public profile where available, then use the Auth API for canonical user identity.
  const known=await db.from("user_profiles").select("id").ilike("email",email).limit(1).maybeSingle();if(known.error)throw known.error;
  let user:any=null,newUser=false;
  if(known.data?.id){const existing=await db.auth.admin.getUserById(known.data.id);if(!existing.error&&existing.data.user&&clean(existing.data.user.email).toLowerCase()===email)user=existing.data.user}
  // Legacy checkout accounts may not yet have a user_profiles row. Scan Auth pages
  // rather than incorrectly concluding after the first 1000 accounts.
  if(!user){for(let page=1;page<=100;page++){const list=await db.auth.admin.listUsers({page,perPage:1000});if(list.error)throw list.error;user=list.data.users.find((u:any)=>clean(u.email).toLowerCase()===email)||null;if(user||list.data.users.length<1000)break}}
  if(!user){const created=await db.auth.admin.createUser({email,email_confirm:true,user_metadata:{first_name:firstName,last_name:lastName,source:"screenings4u_cart_checkout"}});if(created.error)throw created.error;user=created.data.user;newUser=true}
  if(!user)return reply({error:"Unable to establish customer account."},500);
  const profile=await db.from("user_profiles").upsert({id:user.id,first_name:firstName,last_name:lastName,display_name:`${firstName} ${lastName}`,email,phone:clean(customer.phone)||null,status:"active",metadata:{company_name:clean(customer.companyName)||null,address_line_1:clean(customer.address),address_line_2:clean(customer.address2)||null,city:clean(customer.city),state:clean(customer.state).toUpperCase(),postal_code:clean(customer.zip),country:"US"},updated_at:now},{onConflict:"id"});if(profile.error)throw profile.error;
  createdOrderId=crypto.randomUUID();const suffix=createdOrderId.replaceAll("-","").slice(0,8).toUpperCase();const orderNumber=`S4U-${now.slice(0,10).replaceAll("-","")}-${suffix}`;
  const order=await db.from("orders").insert({id:createdOrderId,order_number:orderNumber,user_id:user.id,customer_email:email,customer_first_name:firstName,customer_last_name:lastName,customer_phone:clean(customer.phone)||null,status:"pending",payment_status:"unpaid",subtotal:subtotalCents/100,tax:0,total:amount/100,source:"website",fulfillment_type:"testing",fulfillment_status:"pending",currency,billing_address_line_1:clean(customer.address),billing_address_line_2:clean(customer.address2)||null,billing_city:clean(customer.city),billing_state:clean(customer.state).toUpperCase(),billing_postal_code:clean(customer.zip),billing_country:"US",tracking_number:`TST-${suffix}`,discount_code_id:discountId,discount_code:discountCode,discount_amount:discountAmountCents/100,metadata:{finance_business_code:"testing",seller_surface:"screenings4u_testing",seller_legal_name:"screenings4u, LLC",customer_auth_new:newUser,donor_assignment_status:"awaiting_donors",donor_assignments_required:unitTotal,cart_checkout:true}}).select("id").single();if(order.error)throw order.error;
  // An individual order-item record for EVERY purchased unit keeps the current
  // webhook's order_item_id idempotency and future donor-assignment mapping valid.
  const items=rows.flatMap(x=>Array.from({length:x.quantity},()=>({order_id:createdOrderId,service_id:x.service.id,quantity:1,unit_price:x.unitCents/100,line_total:x.unitCents/100,metadata:{service_slug:x.service.slug,service_name:x.service.name,assignment_deferred:true,assignment_status:"unassigned",labcorp_eligible:x.service.metadata?.labcorp_fulfillment===true}})));
  const itemResult=await db.from("order_items").insert(items);if(itemResult.error)throw itemResult.error;
  const intent=await stripe.paymentIntents.create({amount,currency,receipt_email:email,automatic_payment_methods:{enabled:true},metadata:{order_id:createdOrderId,order_number:orderNumber,business:"testing",cart_checkout:"true",unit_count:String(unitTotal)}},{idempotencyKey:`screenings4u-cart-${createdOrderId}`});createdIntentId=intent.id;
  const updated=await db.from("orders").update({payment_provider:"stripe",payment_reference:intent.id,stripe_payment_intent_id:intent.id,updated_at:new Date().toISOString()}).eq("id",createdOrderId);if(updated.error)throw updated.error;
  return reply({clientSecret:intent.client_secret,stripePublishableKey:publishable,paymentIntentId:intent.id,orderId:createdOrderId,orderNumber,amount,subtotal:subtotalCents/100,total:amount/100,discountAmount:discountAmountCents/100,discountCode,currency:currency.toUpperCase(),testsPurchased:unitTotal});
 }catch(e){console.error("create-cart-payment-intent",e,{createdOrderId,createdIntentId});return reply({error:"Unable to prepare this order. Please retry or contact support."},500)}
});

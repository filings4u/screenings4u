# Step 1 checkout + customer portal handoff — deployment checklist

## Implemented in these ZIPs
- Single-test checkout remains at `checkout.html?service=...`.
- Multi-test cart displays all selected units, totals and secure payment form.
- The Edge Function source `supabase/functions/create-cart-payment-intent/index.ts` creates a paid-order candidate with **one order_items row per purchased test**, marks each as `assignment_deferred`, and uses server-resolved pricing.
- The customer portal Orders and Dashboard pages read existing `orders -> order_items` and show pending donor assignment counts. Order Details lists every test unit and its assignment state.

## Must occur before combined checkout can be deployed
1. Modify and test the deployed `stripe-webhook` to skip deferred items during initial paid fulfillment, while granting account access and sending an assignment-required message (see `supabase/STRIPE-WEBHOOK-DEFERRED-ITEMS-PATCH.md`).
2. Deploy the new Edge Function with existing Stripe and Supabase secrets. Protect payment initiation against automated abuse and verify email/guest-account ownership flows. Its code is present; it is **not** currently deployed.
3. Deploy the updated **storefront ZIP** and **customer portal ZIP** to their separate domains.
4. Execute successful, declined, cancellation, redirect/3DS, webhook replay, coupon, account-reuse and multiple-test integration tests against the same deployed release before accepting customer payments.

**Step 2**, a secure one-by-one donor assignment form and its server-side API, is not part of Step 1. No donor pass should be issued or Labcorp registration submitted before the donor form has been completed and validated.

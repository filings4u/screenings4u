# Checkout integration status

This package uses the existing `checkout.html?service=<slug>` single-test Stripe PaymentIntent flow powered by the deployed `create-payment-intent` Supabase function.

**Combined cart payment is NOT implemented.** The retired unconnected `create-marketplace-cart-payment` client has been removed instead of shipping a broken customer-facing checkout. The old marketplace-checkout URL safely redirects to `cart.html`. Customers can purchase each test through its tested existing individual checkout path.

Before representing the full payment system as production-verified, execute test-mode end-to-end successful/failed/3DS payment scenarios, check the Stripe webhook updates, donor records, order receipt, and Labcorp fulfillment. None of those live-payment tests were performed by this patch.

No payment/backend configuration, credentials, or live database records were changed.

# Screenings4U Step 1 — Multi-test Checkout Release

Supabase production backend deployments (verified 2026-10-09):
- `stripe-webhook` version 65: active. Defers testing case, Labcorp registration, and donor pass creation for line items marked `assignment_deferred=true`. Creates purchaser portal access and assignment reminder.
- `create-cart-payment-intent` version 1: active. Uses server-side Supabase catalog prices and discount eligibility, creates one order item per purchased test, and starts one Stripe PaymentIntent for the full cart.

Frontend:
- Single-test checkout preserved.
- Multi-test checkout shows itemized cart, quantities and totals with donor entry deferred.
- Combined checkout uses `checkout.html?cart=1`; order confirmation links to My Orders, not unissued donor passes.
- Portal order progress integration is supplied separately in `screenings4u-step1-customer-portal-integrated.zip`.

Deployment distinction:
- Backend Edge Functions are deployed in Supabase; this ZIP is NOT automatically deployed to the production website. Upload the storefront and separately deploy the portal package to their respective sites.
- The portal donor-assignment form is Step 2 and not included here.
- No real-money Stripe payment has been submitted. Run a controlled authorized Stripe test and verify webhook, portal visibility and retry behavior before declaring an end-to-end live payment certified.
- Combined checkout currently accepts services with `testing_operation=true` only; other store services continue through supported individual checkout routes.

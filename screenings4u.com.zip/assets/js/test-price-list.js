/**
 * screenings4u
 * Central Test Price & service Catalog
 * Location: assets/js/test-price-list.js
 *
 * IMPORTANT:
 * - Prices are stored in cents for Stripe-compatible calculations.
 * - stripePriceId values are intentionally blank until the matching
 *   Stripe Price objects are created.
 * - This file is the frontend service catalog used by the checkout page.
 */

const TEST_SERVICES = {
  /* =========================================================
     LIVE CHECKOUT TEST SERVICE
     ========================================================= */



  /* =========================================================
     DOT URINE DRUG TESTS
     ========================================================= */

  dot_personal_test: {
    id: "dot_personal_test",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_personal_test",
    name: "DOT Personal Test",
    shortName: "DOT Personal Test",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Ideal for individual compliance and peace of mind.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  dot_pre_employment: {
    id: "dot_pre_employment",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_pre_employment",
    name: "DOT Pre Employment",
    shortName: "DOT Pre Employment",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Quick results to get your drivers on the road faster.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  dot_random_test: {
    id: "dot_random_test",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_random_test",
    name: "DOT Random Test",
    shortName: "DOT Random Test",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Full FMCSA compliance for required random selections.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  dot_reasonable_suspicion: {
    id: "dot_reasonable_suspicion",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_reasonable_suspicion",
    name: "DOT Reasonable Suspicion",
    shortName: "DOT Reasonable Suspicion",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Sensitive handling for workplace safety needs.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  dot_post_accident: {
    id: "dot_post_accident",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_post_accident",
    name: "DOT Post Accident",
    shortName: "DOT Post Accident",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Immediate priority processing when time is critical.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  dot_return_to_duty: {
    id: "dot_return_to_duty",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_return_to_duty",
    name: "DOT Return to Duty",
    shortName: "DOT Return to Duty",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 7495,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Mandatory testing for SAP program compliance.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  dot_follow_up: {
    id: "dot_follow_up",
  orderType: "checkout",
  orderUrl: "checkout.html?service=dot_follow_up",
    name: "DOT Follow Up",
    shortName: "DOT Follow Up",
    category: "DOT Urine Drug Testing",
    specimen: "Urine",
    price: 7495,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Continuous monitored screening for compliance.",
    features: [
      "DOT 5 Panel Urine Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  /* =========================================================
     DOT BREATH ALCOHOL TESTING
     ========================================================= */

  dot_breathalyzer_pre_employment: {
    id: "dot_breathalyzer_pre_employment",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_breathalyzer_pre_employment",
    name: "DOT Breathalyzer - Pre-Employment",
    shortName: "DOT Breathalyzer - Pre-Employment",
    category: "DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 6995,
    currency: "usd",
    stripePriceId: "",
    results: "Instant Results",
    description: "DOT breath alcohol testing support for applicable transportation employment requirements.",
    features: [
      "DOT Breathalyzer Test",
      "Instant Results",
      "Certified Collection Site"
    ]
  },

  dot_breathalyzer_random: {
    id: "dot_breathalyzer_random",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_breathalyzer_random",
    name: "DOT Breathalyzer - Random Testing",
    shortName: "DOT Breathalyzer - Random Testing",
    category: "DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 6995,
    currency: "usd",
    stripePriceId: "",
    results: "Instant Results",
    description: "DOT alcohol testing support for applicable random testing selections and compliance requirements.",
    features: [
      "DOT Breathalyzer Test",
      "Instant Results",
      "Certified Collection Site"
    ]
  },

  dot_breathalyzer_post_accident: {
    id: "dot_breathalyzer_post_accident",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_breathalyzer_post_accident",
    name: "DOT Breathalyzer - Post-Accident",
    shortName: "DOT Breathalyzer - Post-Accident",
    category: "DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 6995,
    currency: "usd",
    stripePriceId: "",
    results: "Instant Results",
    description: "DOT alcohol testing support when a qualifying transportation incident requires testing.",
    features: [
      "DOT Breathalyzer Test",
      "Instant Results",
      "Certified Collection Site"
    ]
  },

  dot_breathalyzer_reasonable_suspicion: {
    id: "dot_breathalyzer_reasonable_suspicion",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_breathalyzer_reasonable_suspicion",
    name: "DOT Breathalyzer - Reasonable Suspicion",
    shortName: "DOT Breathalyzer - Reasonable Suspicion",
    category: "DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 6995,
    currency: "usd",
    stripePriceId: "",
    results: "Instant Results",
    description: "DOT alcohol testing support for applicable reasonable-suspicion testing situations.",
    features: [
      "DOT Breathalyzer Test",
      "Instant Results",
      "Certified Collection Site"
    ]
  },

  dot_breathalyzer_compliance_plus: {
    id: "dot_breathalyzer_compliance_plus",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_breathalyzer_compliance_plus",
    name: "DOT Breathalyzer - Compliance Plus",
    shortName: "DOT Breathalyzer - Compliance Plus",
    category: "DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 14995,
    currency: "usd",
    stripePriceId: "",
    results: "Instant Results",
    description: "Expanded DOT alcohol testing support with additional compliance and program-management services. Valid for one year.",
    features: [
      "DOT Breathalyzer Test",
      "Instant Results",
      "Certified Collection Site",
      "Random Consortium Entry",
      "Result Management Portal",
      "Compliance Audit Support",
      "Consortium Entry Agreement",
      "Compliance Certificate"
    ]
  },

  dot_breathalyzer_enterprise: {
    id: "dot_breathalyzer_enterprise",
    orderType: "custom_form",
    orderUrl: "enterprise-testing-form.html",
    name: "DOT Breathalyzer - Enterprise",
    shortName: "DOT Breathalyzer - Enterprise",
    category: "DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 0,
    currency: "usd",
    stripePriceId: "",
    results: "Custom",
    description: "High-volume DOT alcohol testing solutions for large nationwide fleets with customized reporting solutions.",
    features: [
      "DOT Breathalyzer Tests",
      "Instant Results",
      "Certified Collection Sites",
      "Random Consortium Entry",
      "Result Management Portal",
      "Compliance Audit Support",
      "Consortium Entry Agreement",
      "Compliance Certificate",
      "High Volume Testing",
      "Customized Reporting Solutions for Large Nationwide Fleets"
    ]
  },



  /* =========================================================
     DOT PHYSICAL EXAM SERVICES
     ========================================================= */

  dot_physical_essential: {
    id: "dot_physical_essential",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_physical_essential",
    name: "DOT Physical - Essential",
    shortName: "DOT Physical - Essential",
    category: "DOT Physicals",
    specimen: "N/A",
    price: 17595,
    currency: "usd",
    stripePriceId: "",
    results: "Same Day",
    description: "A complete DOT physical examination covering the core medical and certification requirements for commercial drivers.",
    features: [
      "Full Physical Examination",
      "Vision Check",
      "Hearing Check",
      "Blood Pressure Check",
      "Urinalysis for Medical Conditions",
      "Medical History Review",
      "Certification Card"
    ]
  },

  dot_physical_complete: {
    id: "dot_physical_complete",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_physical_complete",
    name: "DOT Physical - Complete",
    shortName: "DOT Physical - Complete",
    category: "DOT Physicals",
    specimen: "N/A",
    price: 27595,
    currency: "usd",
    stripePriceId: "",
    results: "Same Day",
    description: "A comprehensive DOT physical package that combines the complete medical examination with DOT urine drug and breath alcohol testing.",
    features: [
      "Full Physical Examination",
      "Vision Check",
      "Hearing Check",
      "Blood Pressure Check",
      "Urinalysis for Medical Conditions",
      "Medical History Review",
      "Certification Card",
      "DOT Urine Drug Test",
      "DOT Breathalyzer Test"
    ]
  },

  dot_physical_driver_plus: {
    id: "dot_physical_driver_plus",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_physical_driver_plus",
    name: "DOT Physical - Driver Plus",
    shortName: "DOT Physical - Driver Plus",
    category: "DOT Physicals",
    specimen: "N/A",
    price: 22595,
    currency: "usd",
    stripePriceId: "",
    results: "Same Day",
    description: "A complete DOT physical with added driver-focused documentation support for a straightforward certification process.",
    features: [
      "Full Physical Examination",
      "Vision Check",
      "Hearing Check",
      "Blood Pressure Check",
      "Urinalysis for Medical Conditions",
      "Medical History Review",
      "Certification Card",
      "Driver Documentation Review"
    ]
  },

  dot_physical_compliance: {
    id: "dot_physical_compliance",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_physical_compliance",
    name: "DOT Physical - Compliance",
    shortName: "DOT Physical - Compliance",
    category: "DOT Physicals",
    specimen: "N/A",
    price: 24995,
    currency: "usd",
    stripePriceId: "",
    results: "Same Day",
    description: "A comprehensive DOT physical package designed for drivers who want the examination and additional compliance-focused documentation support in one service.",
    features: [
      "Full Physical Examination",
      "Vision Check",
      "Hearing Check",
      "Blood Pressure Check",
      "Urinalysis for Medical Conditions",
      "Medical History Review",
      "Certification Card",
      "Driver Documentation Review",
      "DOT Compliance Support"
    ]
  },

  employer_driver_physicals: {
    id: "employer_driver_physicals",
    orderType: "custom_form",
    orderUrl: "employer-driver-physical-form.html",
    name: "Employer Driver Physicals",
    shortName: "Employer Driver Physicals",
    category: "DOT Physicals",
    specimen: "N/A",
    price: 0,
    currency: "usd",
    stripePriceId: "",
    results: "Custom",
    description: "Employer-focused DOT physical scheduling and program support for companies managing physical examinations for their commercial drivers.",
    features: [
      "Employer Driver Physical Scheduling",
      "Driver Roster Coordination",
      "DOT Physical Exam Support",
      "Scheduling Assistance",
      "Employer Program Support"
    ]
  },

  dot_medical_exam_support: {
    id: "dot_medical_exam_support",
    orderType: "contact",
    orderUrl: "contact.html",
    name: "DOT Medical Exam Support",
    shortName: "DOT Medical Exam Support",
    category: "DOT Physicals",
    specimen: "N/A",
    price: 0,
    currency: "usd",
    stripePriceId: "",
    results: "Custom",
    description: "Personalized assistance for drivers and employers who need help understanding or coordinating DOT medical examination requirements.",
    features: [
      "DOT Medical Exam Guidance",
      "Medical Documentation Support",
      "Exam Coordination Assistance",
      "Driver Support",
      "Employer Support"
    ]
  },

  /* =========================================================
     URINE DRUG TESTS
     ========================================================= */

  urine_4_panel: {
    id: "urine_4_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_4_panel",
    name: "4 Panel Drug Test",
    shortName: "4 Panel Drug Test",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 4995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Comprehensive screening for 4 common illegal substances.",
    features: [
      "4 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Opiates (OPI)",
      "Phencyclidine (PCP)"
    ]
  },

  urine_5_panel: {
    id: "urine_5_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_5_panel",
    name: "5 Panel Drug Test",
    shortName: "5 Panel Drug Test",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Standard workplace screening for 5 major drug classes.",
    features: [
      "5 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Opiates (Codeine, Morphine, Heroin)",
      "Amphetamines (AMP)",
      "Phencyclidine (PCP)"
    ]
  },

  urine_5_panel_expanded_opiates: {
    id: "urine_5_panel_expanded_opiates",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_5_panel_expanded_opiates",
    name: "5 Panel Drug Test Expanded Opiates",
    shortName: "5 Panel Expanded Opiates",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 6995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Advanced 5-panel test including expanded opiate analysis.",
    features: [
      "5 Panel Drug Test Expanded Opiates",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Phencyclidine (PCP)",
      "Opiates (Codeine, Morphine, Heroin, Hydrocodone, Hydromorphone, Oxycodone & Oxymorphone)"
    ]
  },

  urine_10_panel_lab: {
    id: "urine_10_panel_lab",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_10_panel_lab",
    name: "10 Panel Drug Test (Lab)",
    shortName: "10 Panel Drug Test (Lab)",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 7995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Detailed laboratory analysis for index drug panels.",
    features: [
      "10 Panel Drug Test (Lab)",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Phencyclidine (PCP)",
      "Amphetamines (AMP)",
      "Opiates (heroin, morphine, oxycodone, etc.)",
      "Benzodiazepine (BZO)",
      "Barbiturates (BAR)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)",
      "Methamphetamine (MET)"
    ]
  },

  urine_10_panel_rapid: {
    id: "urine_10_panel_rapid",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_10_panel_rapid",
    name: "10 Panel Drug Test (Rapid)",
    shortName: "10 Panel Drug Test (Rapid)",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 8995,
    currency: "usd",
    stripePriceId: "",
    results: "Instant Results",
    description: "Fast, on-site results for a broad 10-substance spectrum.",
    features: [
      "10 Panel Drug Test (Rapid)",
      "Digital Donor Passes",
      "Instant Results",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Phencyclidine (PCP)",
      "Amphetamines (AMP)",
      "Opiates (heroin, morphine, codeine, etc.)",
      "Benzodiazepine (BZO)",
      "Barbiturates (BAR)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)",
      "Methamphetamine (MET)"
    ]
  },

  urine_12_panel: {
    id: "urine_12_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_12_panel",
    name: "12 Panel Drug Test",
    shortName: "12 Panel Drug Test",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 11595,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Broad spectrum screening for 12 substance groups.",
    features: [
      "12 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Phencyclidine (PCP)",
      "Amphetamines (AMP)",
      "Opiates (OPI) (Codeine, Morphine, etc.)",
      "Barbiturates (BAR)",
      "Benzodiazepine (BZO)",
      "Propoxyphene (PPX)",
      "Methadone (MTD)",
      "Tramadol (TRA)",
      "Fentanyl (FEN)",
      "Meperidine (Pethidine)"
    ]
  },

  urine_14_panel: {
    id: "urine_14_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_14_panel",
    name: "14 Panel Drug Test",
    shortName: "14 Panel Drug Test",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 13595,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Screening for full compliance across 14 substance panels.",
    features: [
      "14 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "6AM",
      "AMP/MAMP",
      "Barbiturates",
      "Benzodiazepine (BZO)",
      "Cocaine Metabolite",
      "ETG/ETS",
      "Marijuana Metabolites",
      "MDMA/MDA",
      "Methadone MTB",
      "Opiates",
      "Oxycodone/Oxymorphone",
      "Phencyclidine",
      "Propoxyphene"
    ]
  },

  urine_18_panel: {
    id: "urine_18_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=urine_18_panel",
    name: "18 Panel Drug Test",
    shortName: "18 Panel Drug Test",
    category: "Urine Drug Testing",
    specimen: "Urine",
    price: 15995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Maximum range screening for full compliance across 18 substance panels.",
    features: [
      "18 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Amphetamines (AMP)",
      "Barbiturates (BAR)",
      "Benzodiazepine (BZO)",
      "Buprenorphine (BUP)",
      "Cocaine (COC)",
      "Ecstasy (MDMA)",
      "Fentanyl (FEN)",
      "Marijuana (THC)",
      "Methadone (MTD)",
      "Methamphetamine (MET)",
      "Morphine (OPI)",
      "Oxycodone (OXY)",
      "Phencyclidine (PCP)",
      "Nortriptyline (TCA)",
      "Ketamin (KET)"
    ]
  },

  /* =========================================================
     HAIR FOLLICLE DRUG TESTS
     ========================================================= */

  hair_5_panel: {
    id: "hair_5_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_5_panel",
    name: "5 Panel Hair Follicle Test",
    shortName: "5 Panel Hair Follicle Test",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 11595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "Standardized 90-day drug screening for five core panels with high accuracy and precision results.",
    features: [
      "5 Panel Hair Follicle Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Opiates (OPI) (Codeine, Morphine, Heroin)",
      "Amphetamines (AMP) (Methamphetamine & Ecstasy)",
      "Phencyclidine (PCP)"
    ]
  },

  hair_5_panel_expanded_opiates: {
    id: "hair_5_panel_expanded_opiates",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_5_panel_expanded_opiates",
    name: "5 Panel Hair Follicle (Exp Opi)",
    shortName: "5 Panel Hair Follicle Expanded Opiates",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 13595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "Expanded opiate screening, including prescription pain medication, for full safety compliance.",
    features: [
      "5 Panel Hair Follicle (Exp Opi)",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Opiates (OPI) (Codeine, Morphine, Heroin, Oxycodone, Hydrocodone, Hydromorphone)",
      "Amphetamines (AMP) (Methamphetamine & Ecstasy)",
      "Phencyclidine (PCP)"
    ]
  },

  hair_7_panel: {
    id: "hair_7_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_7_panel",
    name: "7 Panel Hair Follicle Test",
    shortName: "7 Panel Hair Follicle Test",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 15595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "Advanced screening for seven specific panels, ensuring thorough long-term workplace and legal safety and compliance.",
    features: [
      "7 Panel Hair Follicle Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Barbiturates (BAR)",
      "Benzodiazepines (BZO)",
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Amphetamines (AMP) (methamphetamine & ecstasy)",
      "Phencyclidine (PCP)",
      "Opiates (OPI) (Codeine, Morphine, Heroine, Hydrocodone, Hydromorphone, Oxycodone, Oxymorphone)"
    ]
  },

  hair_9_panel: {
    id: "hair_9_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_9_panel",
    name: "9 Panel Hair Follicle Test",
    shortName: "9 Panel Hair Follicle Test",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 22595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "Comprehensive detection of nine substances, ideal for advanced compliance monitoring programs.",
    features: [
      "9 Panel Hair Follicle Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Barbiturates (BAR)",
      "Benzodiazepines (BZO)",
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Amphetamines (AMP) (methamphetamine & ecstasy)",
      "Phencyclidine (PCP)",
      "Opiates (OPI) (Codeine, Morphine, Heroine, Hydrocodone, Hydromorphone, Oxycodone, Oxymorphone)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)"
    ]
  },

  hair_12_panel: {
    id: "hair_12_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_12_panel",
    name: "12 Panel Hair Follicle Test",
    shortName: "12 Panel Hair Follicle Test",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 47595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "The Gold standard in detailed detection, covering a wide range of illicit and prescription drugs.",
    features: [
      "12 Panel Hair Follicle Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Amphetamines (Methamphetamine & Ecstasy)",
      "Phencyclidine (PCP)",
      "Opiates (OPI) (Codeine, Morphine, Heroin, Oxycodone, Hydrocodone, Hydromorphone)",
      "Barbiturates (BAR)",
      "Benzodiazepines (BZO)",
      "Propoxyphene (PPX)",
      "Methadone (MTD)",
      "Meperidine",
      "Tramadol (TRA)"
    ]
  },

  hair_14_panel: {
    id: "hair_14_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_14_panel",
    name: "14 Panel Hair Follicle Test",
    shortName: "14 Panel Hair Follicle Test",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 59595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "14-panel hair follicle screening with nationwide collection access.",
    features: [
      "14 Panel Hair Follicle Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Propoxyphene (PPX)",
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Amphetamines (AMP) (methamphetamine & ecstasy)",
      "Phencyclidine (PCP)",
      "Opiates (OPI) (Codeine, Morphine, Heroin, Oxycodone, Hydrocodone, Hydromorphone)",
      "Barbiturates (BAR)",
      "Benzodiazepines (BZO)",
      "Methadone (MTD)",
      "Tramadol (TRA)",
      "Sufentanil",
      "Fentanyl (FEN)",
      "Meperidine"
    ]
  },

  hair_17_panel: {
    id: "hair_17_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=hair_17_panel",
    name: "17 Panel Hair Follicle Test",
    shortName: "17 Panel Hair Follicle Test",
    category: "Hair Follicle Drug Testing",
    specimen: "Hair",
    price: 69595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "The 17-panel test covers all substances, including prescription drugs, ensuring safety and legal compliance.",
    features: [
      "17 Panel Hair Follicle Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Amphetamines (AMP)",
      "Methamphetamines (Meth)",
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Opiates (OPI) Synthetic Expanded Opiates (Hydrocodone, Oxycodone)",
      "Fentanyl (FEN)",
      "Tramadol (TRA)",
      "Buprenorphine (BUP)",
      "Phencyclidine (PCP)",
      "Benzodiazepines (BZO)",
      "Barbiturates (BAR)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)",
      "Meperidine",
      "Ketamine",
      "Zolpidem (Ambien)"
    ]
  },

  /* =========================================================
     ETG / ALCOHOL TESTS
     ========================================================= */

  etg_plus_5_panel: {
    id: "etg_plus_5_panel",
    orderType: "checkout",
    orderUrl: "checkout.html?service=etg_plus_5_panel",
    name: "EtG + 5 Panel Drug Test",
    shortName: "EtG + 5 Panel Drug Test",
    category: "EtG Alcohol & Drug Testing",
    specimen: "Urine",
    price: 12995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Comprehensive combined screening for EtG alcohol and 5 major drug classes.",
    features: [
      "EtG + 5 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Ethyl Glucuronide (EtG)",
      "Amphetamines (AMP) (MAMP-Methamphetamine, MDMA-Ecstasy)",
      "Cocaine (COC)",
      "Opiates (OPI) (Codeine, Morphine)",
      "Phencyclidine (PCP)",
      "Marijuana (THC)"
    ]
  },

  etg_plus_10_panel: {
    id: "etg_plus_10_panel",
    orderType: "checkout",
    orderUrl: "checkout.html?service=etg_plus_10_panel",
    name: "EtG + 10 Panel Drug Test",
    shortName: "EtG + 10 Panel Drug Test",
    category: "EtG Alcohol & Drug Testing",
    specimen: "Urine",
    price: 14495,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Expanded panel testing for EtG alcohol and 10 common illicit and prescription substances.",
    features: [
      "EtG + 10 Panel Drug Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Ethyl Glucuronide (EtG)",
      "Amphetamines (AMP) (MAMP-Methamphetamine, MDMA-Ecstasy)",
      "Cocaine (COC)",
      "Opiates (OPI) (Heroin, Codeine, Morphine, Hydrocodone, Hydromorphone, Oxycodone, and Oxymorphone)",
      "Phencyclidine (PCP)",
      "Marijuana (THC)",
      "Benzodiazepines (BZO)",
      "Barbiturates (BAR)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)",
      "Methaqualone (Meth)"
    ]
  },

  etg_urine_alcohol: {
    id: "etg_urine_alcohol",
    orderType: "checkout",
    orderUrl: "checkout.html?service=etg_urine_alcohol",
    name: "EtG Urine Alcohol Test",
    shortName: "EtG Urine Alcohol Test",
    category: "EtG Alcohol Testing",
    specimen: "Urine",
    price: 11595,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Highly accurate urine-based screening for ethyl glucuronide to monitor recent alcohol consumption.",
    features: [
      "EtG Urine Alcohol Test",
      "Digital Donor Passes",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Ethyl Glucuronide (EtG)",
      "ETG (Alcohol Metabolite)"
    ]
  },

  etg_alcohol_hair: {
    id: "etg_alcohol_hair",
    orderType: "checkout",
    orderUrl: "checkout.html?service=etg_alcohol_hair",
    name: "EtG Alcohol Hair Test",
    shortName: "EtG Alcohol Hair Test",
    category: "EtG Alcohol Testing",
    specimen: "Hair",
    price: 39595,
    currency: "usd",
    stripePriceId: "",
    results: "3 to 7 days",
    description: "Long-term monitoring solution detecting alcohol metabolites in hair for a 90-day window.",
    features: [
      "EtG Alcohol Hair Test",
      "Digital Donor Passes",
      "Results in 3 to 7 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Ethyl Glucuronide (EtG)",
      "ETG (Alcohol Metabolite)"
    ]
  },

  /* =========================================================
     ORAL FLUID DRUG TESTS
     ========================================================= */

  oral_5_panel: {
    id: "oral_5_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=oral_5_panel",
    name: "5 Panel Oral Fluid Test",
    shortName: "5 Panel Oral Fluid Test",
    category: "Oral Fluid Drug Testing",
    specimen: "Oral Fluid",
    price: 5995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Observed oral fluid collection with laboratory analysis and secure reporting.",
    features: [
      "Observed Collection",
      "Lab Analysis",
      "Secure Reporting"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Opiates (OPI) (Codeine, Morphine, Heroin)",
      "Amphetamines (AMP) (Methamphetamine & Ecstasy)",
      "Phencyclidine (PCP)"
    ]
  },

  oral_10_panel: {
    id: "oral_10_panel",
  orderType: "checkout",
  orderUrl: "checkout.html?service=oral_10_panel",
    name: "10 Panel Oral Fluid Test",
    shortName: "10 Panel Oral Fluid Test",
    category: "Oral Fluid Drug Testing",
    specimen: "Oral Fluid",
    price: 6995,
    currency: "usd",
    stripePriceId: "",
    results: "2 to 3 days",
    description: "Observed oral fluid collection with expanded laboratory analysis and secure reporting.",
    features: [
      "Observed Collection",
      "Lab Analysis",
      "Secure Reporting"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Phencyclidine (PCP)",
      "Amphetamines (AMP)",
      "Opiates (heroin, codeine, hydrocodone, hydromorphone, oxycodone, and morphine)",
      "Benzodiazepines (BZO)",
      "Barbiturates (BAR)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)",
      "Methamphetamine (MET)"
    ]
  },

  oral_post_accident: {
    id: "oral_post_accident",
  orderType: "checkout",
  orderUrl: "checkout.html?service=oral_post_accident",
    name: "Post-Accident Oral Test",
    shortName: "Post-Accident Oral Test",
    category: "Oral Fluid Drug Testing",
    specimen: "Oral Fluid",
    price: 8995,
    currency: "usd",
    stripePriceId: "",
    results: "Rapid Results",
    description: "Rapid post-accident oral fluid testing with chain of custody and compliance support.",
    features: [
      "Rapid Results",
      "Full Chain of Custody",
      "Compliance Support",
      "Secure Reporting"
    ],
    drugs: [
      "Cocaine (COC)",
      "Marijuana (THC)",
      "Phencyclidine (PCP)",
      "Amphetamines (AMP)",
      "Opiates",
      "Benzodiazepines (BZO)",
      "Barbiturates (BAR)",
      "Methadone (MTD)",
      "Propoxyphene (PPX)",
      "Methamphetamine (MET)"
    ]
  },

  
  /* =========================================================
     DOT RANDOM DRUG & ALCOHOL CONSORTIUM
     ========================================================= */

  dot_consortium_basic: {
    id: "dot_consortium_basic",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_consortium_basic",
    name: "DOT Consortium - Basic Compliance",
    shortName: "Basic Compliance",
    category: "DOT Random Drug & Alcohol Consortium",
    specimen: "N/A",
    price: 5495,
    currency: "usd",
    stripePriceId: "",
    results: "1-year enrollment",
    description: "Annual DOT random drug and alcohol consortium enrollment for owner-operators and single-driver companies.",
    features: [
      "Random selection management",
      "Enrollment Certificate",
      "Annual MIS reporting support",
      "Compliance Certificate",
      "Random Drug Testing program administration",
      "Random Alcohol Testing program administration",
      "Secure online access to selection notices",
      "Compliance reminders by email"
    ]
  },

  dot_consortium_standard_fleet: {
    id: "dot_consortium_standard_fleet",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_consortium_standard_fleet",
    name: "DOT Consortium - Standard Fleet",
    shortName: "Standard Fleet",
    category: "DOT Random Drug & Alcohol Consortium",
    specimen: "N/A",
    price: 10590,
    currency: "usd",
    stripePriceId: "",
    results: "1-year enrollment",
    description: "Annual DOT random program management plan for fleets with 2 to 25 drivers.",
    features: [
      "Everything in Basic Compliance",
      "DOT Drug Test (All DOT Agencies)",
      "DOT random program management for your entire team",
      "Dedicated account support for your company",
      "Centralized employer portal for all drivers",
      "Assistance with pre-employment test coordination",
      "Simple driver add/remove management",
      "Annual compliance review summary"
    ]
  },

  dot_consortium_plus_drug_test: {
    id: "dot_consortium_plus_drug_test",
    orderType: "checkout",
    orderUrl: "checkout.html?service=dot_consortium_plus_drug_test",
    name: "DOT Consortium + Drug Test",
    shortName: "Consortium + Drug Test",
    category: "DOT Random Drug & Alcohol Consortium",
    specimen: "Urine",
    price: 11595,
    currency: "usd",
    stripePriceId: "",
    results: "1-year enrollment + drug test",
    description: "Annual DOT random drug and alcohol consortium enrollment bundled with one DOT 5-panel urine drug test.",
    features: [
      "DOT Random Drug & Alcohol Consortium",
      "Random selection management",
      "Enrollment Certificate",
      "Annual MIS reporting support",
      "Compliance Certificate",
      "Random Drug & Alcohol program administration",
      "Secure online access to selection notices",
      "Compliance reminders by email",
      "DOT 5 Panel Urine Test",
      "Digital Donor Pass",
      "Results in 2 to 3 days",
      "Nationwide Collection Sites",
      "Secure Online Results"
    ],
    drugs: [
      "Marijuana (THC)",
      "Cocaine (COC)",
      "Amphetamines (AMP)",
      "Opioids (OPI)",
      "Phencyclidine (PCP)"
    ]
  },


  /* =========================================================
     MOBILE DRUG TESTING BUSINESS LAUNCH PACKAGES
     ========================================================= */

  "mobile-drug-testing-launch-starter": {
    id: "mobile-drug-testing-launch-starter",
    orderType: "checkout",
    orderUrl: "checkout.html?service=mobile-drug-testing-launch-starter",
    sourcePage: "start-a-mobile-drug-testing-business.html",
    name: "Mobile Drug Testing Business — Starter Launch",
    shortName: "Starter Package",
    category: "Mobile Drug Testing Business Launch",
    specimen: "N/A",
    price: 249500,
    currency: "usd",
    stripePriceId: "",
    results: "Mobile business launch implementation",
    description: "Mobile drug testing business starter package with collector training, business setup, branding, website, lab account support, starter supplies, and launch planning.",
    features: [
      "Mobile launch strategy session and startup roadmap",
      "DOT urine specimen collector training enrollment",
      "Oral fluid collector training enrollment",
      "Hair specimen collection training enrollment",
      "Business entity filing coordination",
      "EIN application assistance",
      "Professional logo and starter brand kit",
      "5-page professional website and domain configuration",
      "Business email setup",
      "House Lab Account setup",
      "Starter CCF and collection supply package",
      "Mobile service menu and pricing worksheet",
      "screenings4u Collector Network onboarding"
    ]
  },

  "mobile-drug-testing-growth": {
    id: "mobile-drug-testing-growth",
    orderType: "checkout",
    orderUrl: "checkout.html?service=mobile-drug-testing-growth",
    sourcePage: "start-a-mobile-drug-testing-business.html",
    name: "Mobile Drug Testing Business — Growth Launch",
    shortName: "Growth Package",
    category: "Mobile Drug Testing Business Launch",
    specimen: "N/A",
    price: 349500,
    currency: "usd",
    stripePriceId: "",
    results: "Expanded mobile business launch implementation",
    description: "Expanded mobile launch package with C/TPA setup, consortium software, MRO/results workflows, scheduling, CRM, local SEO, employer outreach, and coaching.",
    features: [
      "Everything in Starter Package",
      "Registered agent setup coordination",
      "C/TPA setup and Clearinghouse registration support",
      "Random consortium software onboarding",
      "DOT compliance policy starter manual",
      "MRO and electronic results workflow configuration",
      "Booking and scheduling software setup",
      "CRM setup for employers and leads",
      "Google Business Profile setup",
      "Local SEO configuration",
      "Department of Revenue account setup assistance",
      "Employer outreach and sales templates",
      "Two one-on-one launch coaching sessions"
    ]
  },

  "mobile-drug-testing-elite": {
    id: "mobile-drug-testing-elite",
    orderType: "checkout",
    orderUrl: "checkout.html?service=mobile-drug-testing-elite",
    sourcePage: "start-a-mobile-drug-testing-business.html",
    name: "Mobile Drug Testing Business — Elite Launch",
    shortName: "Elite Package",
    category: "Mobile Drug Testing Business Launch",
    specimen: "N/A",
    price: 449500,
    currency: "usd",
    stripePriceId: "",
    results: "Full mobile business launch implementation",
    description: "Full mobile launch package with deeper implementation support, business and marketing plans, licensing assistance, TPA infrastructure, HR/payroll setup, and growth planning.",
    features: [
      "Everything in Growth Package",
      "Three VIP implementation coaching sessions",
      "Operating agreement document setup support",
      "City business license filing assistance",
      "CLIA waiver application support when applicable",
      "Business plan development",
      "Marketing plan development",
      "SAM.gov / CAGE registration assistance",
      "HR software setup",
      "Payroll software setup",
      "Mobile route and service-area strategy",
      "Multi-site growth planning",
      "90-day launch action plan",
      "Priority implementation support"
    ]
  },

  /* =========================================================
     DRUG TESTING BUSINESS LAUNCH PACKAGES
     ========================================================= */

  "drug-testing-business-launch-foundation": {
    id: "drug-testing-business-launch-foundation",
    orderType: "checkout",
    orderUrl: "checkout.html?service=drug-testing-business-launch-foundation",
    sourcePage: "start-a-drug-testing-business.html",
    name: "Drug Testing Business — Launch Foundation",
    shortName: "Launch Foundation",
    category: "Drug Testing Business Launch",
    specimen: "N/A",
    price: 249500,
    currency: "usd",
    stripePriceId: "",
    results: "Business launch implementation",
    description: "Core drug testing business launch package with collector training enrollment, business setup support, branding, website, lab account setup, starter supplies, and launch planning.",
    features: [
      "Launch strategy session and startup roadmap",
      "DOT urine specimen collector training enrollment",
      "Oral fluid collector training enrollment",
      "Hair specimen collection training enrollment",
      "Business entity filing coordination",
      "EIN application assistance",
      "Professional logo and starter brand kit",
      "5-page professional website and domain configuration",
      "Business email setup",
      "House Lab Account setup",
      "Starter CCF and collection supply package",
      "screenings4u Collector Network onboarding",
      "Starter service menu and pricing worksheet"
    ]
  },

  "drug-testing-business-growth-operations": {
    id: "drug-testing-business-growth-operations",
    orderType: "checkout",
    orderUrl: "checkout.html?service=drug-testing-business-growth-operations",
    sourcePage: "start-a-drug-testing-business.html",
    name: "Drug Testing Business — Growth & Operations",
    shortName: "Growth & Operations",
    category: "Drug Testing Business Launch",
    specimen: "N/A",
    price: 349500,
    currency: "usd",
    stripePriceId: "",
    results: "Expanded business launch implementation",
    description: "Expanded launch package with the Launch Foundation plus C/TPA setup, consortium software onboarding, results workflows, scheduling, CRM, local SEO, outreach tools, and coaching.",
    features: [
      "Everything in Launch Foundation",
      "C/TPA setup and Clearinghouse registration support",
      "Random consortium software onboarding",
      "MRO and electronic results workflow configuration",
      "DOT program administration starter templates",
      "Booking and scheduling software setup",
      "CRM setup for leads and employers",
      "Google Business Profile setup",
      "Local SEO configuration",
      "Employer outreach and sales templates",
      "Marketing materials starter package",
      "Two one-on-one launch coaching sessions",
      "Operational readiness review"
    ]
  },

  "drug-testing-business-full-service-tpa": {
    id: "drug-testing-business-full-service-tpa",
    orderType: "checkout",
    orderUrl: "checkout.html?service=drug-testing-business-full-service-tpa",
    sourcePage: "start-a-drug-testing-business.html",
    name: "Drug Testing Business — Full-Service TPA Launch",
    shortName: "Full-Service TPA Launch",
    category: "Drug Testing Business Launch",
    specimen: "N/A",
    price: 449500,
    currency: "usd",
    stripePriceId: "",
    results: "Full-service business launch implementation",
    description: "Full-service drug testing business launch package with TPA infrastructure, business and marketing plans, deeper implementation support, licensing assistance, software setup, and multi-site growth planning.",
    features: [
      "Everything in Growth & Operations",
      "Three VIP implementation coaching sessions",
      "Business plan development",
      "Marketing plan development",
      "Operating agreement document setup support",
      "City business license filing assistance",
      "CLIA waiver application support when applicable",
      "SAM.gov / CAGE registration assistance",
      "HR software setup",
      "Payroll software setup",
      "Multi-site and mobile growth strategy",
      "90-day launch action plan",
      "Priority implementation support"
    ]
  },

  /* =========================================================
     HOUSE LAB ACCOUNT SETUP
     ========================================================= */

  "lab-account": {
    id: "lab-account",
    orderType: "checkout",
    orderUrl: "checkout.html?service=lab-account",
    sourcePage: "house-lab-account-setup.html",
    name: "Lab Account",
    shortName: "Lab Account",
    category: "Testing Business Services - House Lab Accounts",
    specimen: "N/A",
    price: 28630,
    currency: "usd",
    stripePriceId: "",
    results: "Account setup",
    description: "Professional house lab account setup with supplies, Workforce Portal access, and DOT/NON-DOT urine lab account support.",
    features: [
      "Pack of NON-DOT CCFs (25)",
      "Pack of DOT CCFs (25)",
      "Shipping Supplies",
      "Case of Collection Kits (25)",
      "Workforce Portal",
      "View and Download Results",
      "NON-DOT Urine Lab Account",
      "DOT Urine Lab Account"
    ]
  },

  "lab-account-random-consortium": {
    id: "lab-account-random-consortium",
    orderType: "checkout",
    orderUrl: "checkout.html?service=lab-account-random-consortium",
    sourcePage: "house-lab-account-setup.html",
    name: "Lab Account + Random Consortium",
    shortName: "Lab Account + Random Consortium",
    category: "Testing Business Services - House Lab Accounts",
    specimen: "N/A",
    price: 46130,
    currency: "usd",
    stripePriceId: "",
    results: "Account setup",
    description: "House lab account setup with supplies, Workforce Portal access, DOT/NON-DOT urine lab support, and random consortium management.",
    features: [
      "Pack of NON-DOT CCFs (25)",
      "Pack of DOT CCFs (25)",
      "Shipping Supplies",
      "Case of Collection Kits (25)",
      "Workforce Portal",
      "View and Download Results",
      "NON-DOT Urine Lab Account",
      "DOT Urine Lab Account",
      "Create Consortiums",
      "Manage Consortiums"
    ]
  },

  "lab-account-random-consortium-docs": {
    id: "lab-account-random-consortium-docs",
    orderType: "checkout",
    orderUrl: "checkout.html?service=lab-account-random-consortium-docs",
    sourcePage: "house-lab-account-setup.html",
    name: "Lab Account + Random Consortium + Docs",
    shortName: "Lab Account + Random Consortium + Docs",
    category: "Testing Business Services - House Lab Accounts",
    specimen: "N/A",
    price: 51630,
    currency: "usd",
    stripePriceId: "",
    results: "Account setup",
    description: "Expanded house lab account setup with random consortium management, owner-operator compliance documents, and Clearinghouse account setup.",
    features: [
      "Pack of NON-DOT CCFs (25)",
      "Pack of DOT CCFs (25)",
      "Shipping Supplies",
      "Case of Collection Kits (25)",
      "Workforce Portal",
      "View and Download Results",
      "NON-DOT Urine Lab Account",
      "DOT Urine Lab Account",
      "Create Consortiums",
      "Manage Consortiums",
      "Certificate for owner-operator compliance",
      "Owner-operator agreement",
      "Clearinghouse Account Setup"
    ]
  },


  /* =========================================================
     CLEARINGHOUSE C/TPA SERVICES
     ========================================================= */



  ctpa_custom_solutions: {
    id: "ctpa_custom_solutions",
    orderType: "contact",
    orderUrl: "contact.html?subject=ctpa-custom-solutions",
    name: "C/TPA Custom Solutions",
    shortName: "C/TPA Custom Solutions",
    category: "Clearinghouse C/TPA Services",
    specimen: "N/A",
    price: 0,
    currency: "usd",
    stripePriceId: "",
    results: "Custom",
    description: "Custom Clearinghouse C/TPA solutions for multi-office and high-volume operations.",
    features: [
      "Advanced Clearinghouse workflows",
      "Random consortium software support",
      "High-volume client management",
      "Multi-office scaling",
      "White-label support options",
      "Audit-focused workflow planning",
      "Dedicated account support"
    ]
  },


  non_dot_breathalyzer_test: {
    id: "non_dot_breathalyzer_test",
    orderType: "checkout",
    orderUrl: "checkout.html?service=non_dot_breathalyzer_test",
    name: "Breathalyzer Test",
    shortName: "Breathalyzer Test",
    category: "NON-DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 6995,
    currency: "usd",
    results: "Instant Results",
    description: "NON-DOT breath alcohol testing service."
  },
  non_dot_breathalyzer_legal_court: {
    id: "non_dot_breathalyzer_legal_court",
    orderType: "checkout",
    orderUrl: "checkout.html?service=non_dot_breathalyzer_legal_court",
    name: "Legal & Court Support",
    shortName: "Legal & Court Support",
    category: "NON-DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 8995,
    currency: "usd",
    results: "Instant Results",
    description: "NON-DOT breath alcohol testing with legal or court-support documentation."
  },
  non_dot_breathalyzer_workplace: {
    id: "non_dot_breathalyzer_workplace",
    orderType: "checkout",
    orderUrl: "checkout.html?service=non_dot_breathalyzer_workplace",
    name: "Workplace Package",
    shortName: "Workplace Package",
    category: "NON-DOT Breath Alcohol Testing",
    specimen: "Breath",
    price: 12995,
    currency: "usd",
    results: "Instant Results",
    description: "NON-DOT workplace breath alcohol testing package."
  },
  drug_alcohol_policy_basic: {
    id: "drug_alcohol_policy_basic",
    orderType: "checkout",
    orderUrl: "checkout.html?service=drug_alcohol_policy_basic",
    name: "Basic Policy",
    shortName: "Basic Policy",
    category: "Drug & Alcohol Policy Creation",
    specimen: "N/A",
    price: 29595,
    currency: "usd",
    results: "Policy creation service",
    description: "Basic drug and alcohol policy creation package."
  },
  drug_alcohol_policy_standard: {
    id: "drug_alcohol_policy_standard",
    orderType: "checkout",
    orderUrl: "checkout.html?service=drug_alcohol_policy_standard",
    name: "Standard Policy",
    shortName: "Standard Policy",
    category: "Drug & Alcohol Policy Creation",
    specimen: "N/A",
    price: 49595,
    currency: "usd",
    results: "Policy creation service",
    description: "Standard drug and alcohol policy creation package."
  },
  drug_alcohol_policy_premium: {
    id: "drug_alcohol_policy_premium",
    orderType: "checkout",
    orderUrl: "checkout.html?service=drug_alcohol_policy_premium",
    name: "Premium Policy",
    shortName: "Premium Policy",
    category: "Drug & Alcohol Policy Creation",
    specimen: "N/A",
    price: 89595,
    currency: "usd",
    results: "Policy creation service",
    description: "Premium drug and alcohol policy creation package."
  },
  dna_father_child_non_legal: { id:"dna_father_child_non_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_father_child_non_legal",name:"Father & Child — Non-Legal",shortName:"Father & Child — Non-Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:32500,currency:"usd",results:"DNA testing service",description:"Non-legal father and child DNA relationship test." },
  dna_father_child_legal: { id:"dna_father_child_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_father_child_legal",name:"Father & Child — Legal",shortName:"Father & Child — Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Legal father and child DNA relationship test." },
  dna_mother_child_non_legal: { id:"dna_mother_child_non_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_mother_child_non_legal",name:"Mother & Child — Non-Legal",shortName:"Mother & Child — Non-Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:32500,currency:"usd",results:"DNA testing service",description:"Non-legal mother and child DNA relationship test." },
  dna_mother_child_legal: { id:"dna_mother_child_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_mother_child_legal",name:"Mother & Child — Legal",shortName:"Mother & Child — Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Legal mother and child DNA relationship test." },
  dna_full_siblingship_with_parent: { id:"dna_full_siblingship_with_parent",orderType:"checkout",orderUrl:"checkout.html?service=dna_full_siblingship_with_parent",name:"Full Siblingship — With Parent",shortName:"Full Siblingship — With Parent",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Full siblingship DNA test with parent." },
  dna_full_siblingship_with_parent_legal: { id:"dna_full_siblingship_with_parent_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_full_siblingship_with_parent_legal",name:"Full Siblingship — With Parent Legal",shortName:"Full Siblingship — With Parent Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:52500,currency:"usd",results:"DNA testing service",description:"Legal full siblingship DNA test with parent." },
  dna_full_siblingship_without_parent: { id:"dna_full_siblingship_without_parent",orderType:"checkout",orderUrl:"checkout.html?service=dna_full_siblingship_without_parent",name:"Full Siblingship — Without Parent",shortName:"Full Siblingship — Without Parent",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Full siblingship DNA test without parent." },
  dna_full_siblingship_without_parent_legal: { id:"dna_full_siblingship_without_parent_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_full_siblingship_without_parent_legal",name:"Full Siblingship — Without Parent Legal",shortName:"Full Siblingship — Without Parent Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:52500,currency:"usd",results:"DNA testing service",description:"Legal full siblingship DNA test without parent." },
  dna_half_siblingship_with_parent: { id:"dna_half_siblingship_with_parent",orderType:"checkout",orderUrl:"checkout.html?service=dna_half_siblingship_with_parent",name:"Half Siblingship — With Parent",shortName:"Half Siblingship — With Parent",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Half siblingship DNA test with parent." },
  dna_half_siblingship_with_parent_legal: { id:"dna_half_siblingship_with_parent_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_half_siblingship_with_parent_legal",name:"Half Siblingship — With Parent Legal",shortName:"Half Siblingship — With Parent Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:52500,currency:"usd",results:"DNA testing service",description:"Legal half siblingship DNA test with parent." },
  dna_half_siblingship_without_parent: { id:"dna_half_siblingship_without_parent",orderType:"checkout",orderUrl:"checkout.html?service=dna_half_siblingship_without_parent",name:"Half Siblingship — Without Parent",shortName:"Half Siblingship — Without Parent",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Half siblingship DNA test without parent." },
  dna_half_siblingship_without_parent_legal: { id:"dna_half_siblingship_without_parent_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_half_siblingship_without_parent_legal",name:"Half Siblingship — Without Parent Legal",shortName:"Half Siblingship — Without Parent Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:52500,currency:"usd",results:"DNA testing service",description:"Legal half siblingship DNA test without parent." },
  dna_trio_paternity_non_legal: { id:"dna_trio_paternity_non_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_trio_paternity_non_legal",name:"Standard Trio Paternity — Non-Legal",shortName:"Standard Trio Paternity — Non-Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:42500,currency:"usd",results:"DNA testing service",description:"Non-legal standard trio paternity DNA test." },
  dna_trio_paternity_legal: { id:"dna_trio_paternity_legal",orderType:"checkout",orderUrl:"checkout.html?service=dna_trio_paternity_legal",name:"Standard Trio Paternity — Legal",shortName:"Standard Trio Paternity — Legal",category:"DNA Testing — Chicago",specimen:"DNA",price:52500,currency:"usd",results:"DNA testing service",description:"Legal standard trio paternity DNA test." },

};



const SCREENINGS4U_PUBLIC_TESTING_IDS = new Set(["dna_father_child_legal", "dna_father_child_non_legal", "dna_full_siblingship_with_parent", "dna_full_siblingship_with_parent_legal", "dna_full_siblingship_without_parent", "dna_full_siblingship_without_parent_legal", "dna_half_siblingship_with_parent", "dna_half_siblingship_with_parent_legal", "dna_half_siblingship_without_parent", "dna_half_siblingship_without_parent_legal", "dna_mother_child_legal", "dna_mother_child_non_legal", "dna_trio_paternity_legal", "dna_trio_paternity_non_legal", "dot_breathalyzer_post_accident", "dot_breathalyzer_pre_employment", "dot_breathalyzer_random", "dot_breathalyzer_reasonable_suspicion", "dot_follow_up", "dot_personal_test", "dot_physical_complete", "dot_physical_compliance", "dot_physical_driver_plus", "dot_physical_essential", "dot_post_accident", "dot_pre_employment", "dot_random_test", "dot_reasonable_suspicion", "dot_return_to_duty", "drug-testing-business-full-service-tpa", "drug-testing-business-growth-operations", "drug-testing-business-launch-foundation", "drug_alcohol_policy_basic", "drug_alcohol_policy_premium", "drug_alcohol_policy_standard", "etg_alcohol_hair", "etg_plus_10_panel", "etg_plus_5_panel", "etg_urine_alcohol", "hair_12_panel", "hair_14_panel", "hair_17_panel", "hair_5_panel", "hair_5_panel_expanded_opiates", "hair_7_panel", "hair_9_panel", "lab-account", "lab-account-random-consortium", "lab-account-random-consortium-docs", "mobile-drug-testing-elite", "mobile-drug-testing-growth", "mobile-drug-testing-launch-starter", "non_dot_breathalyzer_legal_court", "non_dot_breathalyzer_test", "non_dot_breathalyzer_workplace", "oral_10_panel", "oral_5_panel", "oral_post_accident", "urine_10_panel_lab", "urine_10_panel_rapid", "urine_12_panel", "urine_14_panel", "urine_18_panel", "urine_4_panel", "urine_5_panel", "urine_5_panel_expanded_opiates"]);
let SCREENINGS4U_LIVE_CATALOG_LOADED = false;
async function refreshTestingCatalog(){
  if(SCREENINGS4U_LIVE_CATALOG_LOADED) return getAllTestServices();
  try{
    const base=(window.SCREENINGS4U_SUPABASE_URL||"").replace(/\/+$/,"");
    if(!base) return getAllTestServices();
    const r=await fetch(base+"/functions/v1/public-testing-catalog",{headers:{apikey:window.SCREENINGS4U_SUPABASE_ANON_KEY||""}});
    const d=await r.json();
    if(!r.ok||!Array.isArray(d.services)) throw new Error(d.error||"Catalog unavailable");
    for(const item of d.services){TEST_SERVICES[item.id]={...(TEST_SERVICES[item.id]||{}),...item};SCREENINGS4U_PUBLIC_TESTING_IDS.add(item.id);}
    SCREENINGS4U_LIVE_CATALOG_LOADED=true;
  }catch(e){console.warn("Using local Testing catalog fallback.",e)}
  return getAllTestServices();
}

/* =========================================================
   service CATALOG HELPERS
   ========================================================= */

/**
 * Get a service by its ID.
 */
function getTestService(serviceId) {
  if (!serviceId || !TEST_SERVICES[serviceId]) {
    return null;
  }

  return SCREENINGS4U_PUBLIC_TESTING_IDS.has(serviceId) ? TEST_SERVICES[serviceId] : null;
}

/**
 * Return every service in the catalog.
 */
function getAllTestServices() {
  return Object.values(TEST_SERVICES).filter(service => SCREENINGS4U_PUBLIC_TESTING_IDS.has(service.id));
}

/**
 * Return services belonging to a category.
 */
function getTestServicesByCategory(category) {
  return getAllTestServices().filter(
    (service) => service.category === category
  );
}

/**
 * Convert cents into a display price.
 *
 * Example:
 * 5995 -> "$59.95"
 */
function formatTestPrice(priceInCents, currency = "USD") {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency
  }).format(priceInCents / 100);
}

/**
 * Get the Stripe-compatible amount in cents.
 */
function getStripeAmount(serviceId) {
  const service = getTestService(serviceId);

  return service ? service.price : null;
}

/**
 * Basic catalog validation.
 *
 * This does not replace backend validation.
 */

/**
 * Returns the correct customer-facing order destination for a service.
 *
 * Paid services use the universal checkout page with the service ID.
 * Custom-pricing services use their designated inquiry form.
 */
function getTestOrderUrl(serviceId) {
  const service = getTestService(serviceId);

  if (!service) {
    return null;
  }

  if (service.orderUrl) {
    return service.orderUrl;
  }

  if (service.orderType === "contact") {
    return "contact.html";
  }

  if (service.orderType === "custom_form") {
    return "contact.html";
  }

  return "checkout.html?service=" + encodeURIComponent(service.id);
}

function validateTestService(serviceId) {
  const service = getTestService(serviceId);

  if (!service) {
    return {
      valid: false,
      reason: "service not found."
    };
  }

  if (!service.name) {
    return {
      valid: false,
      reason: "service pricing is invalid."
    };
  }

  if (!["custom_form", "contact"].includes(service.orderType) && (!service.price || service.price <= 0)) {
    return {
      valid: false,
      reason: "service pricing is invalid."
    };
  }

  return {
    valid: true,
    service
  };
}


/* =========================================================
   OPTIONAL GLOBAL ACCESS
   ========================================================= */

window.Screenings4UTestCatalog = {
  services: TEST_SERVICES,
  getTestService,
  getAllTestServices,
  getTestServicesByCategory,
  formatTestPrice,
  getStripeAmount,
  validateTestService,
  refreshTestingCatalog
};

window.refreshTestingCatalog = refreshTestingCatalog;

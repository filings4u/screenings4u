# screenings4u — Brand Palette Update

Updated October 8, 2026.

## Approved colors

- Primary navy: `#24467f` (headers, navigation, prominent text, dark sections).
- Soft background: `#f4f7fc` (alternating sections, hero backgrounds, panels).
- Accent orange: `#ff6b00` (CTAs, emphasis, interactive accents).

Related deeper/lighter shades and white continue where required for hierarchy, contrast, states, and accessibility. Semantic status colors (success, error, warning) are intentionally preserved.

## Scope

All website HTML, CSS, JavaScript, JSON and XML sources scanned. Replaced prior primary `#325aa3` and competing near-white background shades with the approved primary and surface palette. The shared content width is 1450px. Existing features and page layouts were preserved.

## Deployment

Publish the complete package as one update, so HTML, CSS and cached assets remain in sync. Visually verify live pages and embedded third-party widgets before production rollout.

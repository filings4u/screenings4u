# screenings4u cleanup report

Only files without stylesheet/script references in any included HTML page or local CSS import, and explicit duplicate/backup files, were removed. Original upload remains untouched. Files not linked internally but potentially used by external systems (e.g., redirects, checkout callbacks and search engine verification) were retained.

## Removed files
- `assets/css/app.css`
- `assets/css/base.css`
- `assets/css/components.css`
- `assets/css/desktop-nav.css`
- `assets/css/index.css`
- `assets/css/legal.css`
- `assets/css/mobile-nav.css`
- `assets/css/services.css`
- `assets/css/site-shell.css`
- `assets/css/style.css`
- `assets/css/styles.css`
- `assets/js/app.js`
- `assets/js/business-services.js`
- `assets/js/checkout copy.js`
- `assets/js/client-order-detail.js`
- `assets/js/components.js`
- `assets/js/consulting-services.js`
- `assets/js/court-ordered-etg-drug-and-alcohol-testing.js`
- `assets/js/desktop-nav.js`
- `assets/js/dot-services.js`
- `assets/js/dot-specimen-collector-training-group-training.js`
- `assets/js/dot-specimen-collector-training.js`
- `assets/js/drug-testing-management-software.js`
- `assets/js/index.js`
- `assets/js/mobile-nav.js`
- `assets/js/new-entrant-audit.js`
- `assets/js/s4u-webhook-validator.js`
- `assets/js/service.js`
- `assets/js/services.js`
- `index copy.html`
- `screenigns4u.com.zip`

## Preserved
- All active HTML pages, including customer-flow endpoints and externally linked redirects.
- All script and stylesheet assets referenced by any included HTML page or CSS import.
- Verification and SEO files.
